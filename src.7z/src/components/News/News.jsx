import React from 'react';

const News = () => {
    return (
        <div>This is music component</div>
    );
}

export default News;