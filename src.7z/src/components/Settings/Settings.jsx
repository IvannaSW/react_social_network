import React from 'react';

const Settings = () => {
    return (
        <div>This is music component</div>
    );
}

export default Settings;