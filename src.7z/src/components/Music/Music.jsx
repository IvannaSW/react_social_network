import React from 'react';

const Music = () => {
    return (
        <div>This is music component</div>
    );
}

export default Music;