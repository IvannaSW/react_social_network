const sidebarReducer = (state, action) => {
    return state;
}

export default sidebarReducer;