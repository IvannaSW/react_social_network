let initialState = {
    friends: [
        {id:1, name: 'Svitlana'},
        {id:2, name: 'Olha'},
        {id:3, name: 'Mykola'}            
    ]
};

const sidebarReducer = (state = initialState, action) => {
    return state;
}

export default sidebarReducer;